OVERVIEW

--- 

This program simulates parallel processing across three CPU core subprocesses.
The main process acts as a scheduler: it decomposes a job into independent tasks,
distributes them to idle cores, collects results, and prints a summary when all tasks are done.

Each task is defined by a task_id and a randomly chosen bit count n (made by task_creator function). 
The subprocesses call task_handler function to: 
    - read the message from pipe and parse 
    - call function execute_task function to compute the result by extracting the lowest n bits of task_id using a bitmask 
    - send the signal to parent by calling kill()   
    - return the result to the main process.

The three key IPC mechanisms used are:
  - Pipes: each core has two dedicated pipes (main_to_core and core_to_main) for two-way communication with the parent.

  - Signals: each core uses a unique real-time signal (SIGRTMAX, SIGRTMAX-1, SIGRTMAX-2) to notify the parent that a result is ready. 
    Real-time signals are used to avoid signal loss when two cores finish nearly simultaneously.

  - Collecting results based on signals: rather than blocking on read() after each task assignment (which would serialize execution and defeat parallelism),
    the parent only reads a result pipe when the corresponding signal counter (msg_num_coreX) is greater than zero. This keeps all three cores running concurrently.

The scheduling loop in main() continuously assigns tasks to idle cores and 
checks all three signal counters on every iteration, ensuring no result sits unread longer than one loop cycle.
 
---

1. Processes

---

1.i. Children processes are correctly created (10 pts)
    Three child processes are created using fork(), one for each core.
    Each child immediately closes unneeded pipe ends and calls task_handler()
    to enter its work loop. See lines:
 
        pid_t pid1 = fork();   // Core 1 child
        pid_t pid2 = fork();   // Core 2 child
        pid_t pid3 = fork();   // Core 3 child
 
    Each if(pidX == 0){...} block in main() defines the child's behavior.
    The child calls task_handler(read_pipe, write_pipe, signum) which loops
    on read(), processes each task, and writes the result back.

1.ii. Processes are reaped (4 pts)
    After the main work loop completes and all pipes are closed, the parent
    calls wait(NULL) three times to reap all three children:

        wait(NULL);
        wait(NULL);
        wait(NULL);
 
    This is located near the bottom of main(), after the pipe cleanup loop.

---

2. Pipes 

--- 

2.i. Pipes support two-way communication correctly (4 pts)
    Two pipe arrays are created for each core, one in each direction:
 
        int main_to_core[3][2];   // parent writes, child reads
        int core_to_main[3][2];   // child writes, parent reads
 
    This gives each core a dedicated bidirectional communication channel,
    created with pipe() in a loop before any fork() calls.

2.ii.  Corresponding pipe ends are correctly closed on parent and child ends (8 pts)
    In each child block, the child closes the write end of main_to_core[i]
    (it only reads from it) and the read end of core_to_main[i] (it only
    writes to it). It also closes ALL ends of the other two cores' pipes
    since they are irrelevant to that child. Example for Core 1:
 
        close(main_to_core[0][1]);   // child doesn't write to this
        close(core_to_main[0][0]);   // child doesn't read from this
        // close all ends of core 2 and 3 pipes
 
    In the parent, after all forks, the read ends of main_to_core and the
    write ends of core_to_main are closed:
 
        close(main_to_core[i][0]);
        close(core_to_main[i][1]);

2.iii. All pipes are correctly closed in the clean-up stage (4 pts)
    After the main scheduling loop finishes (all tasks completed), the parent
    explicitly closes its remaining open pipe ends:
 
        for(int i = 0; i < 3; i++){
            close(write_pipes[i]);   // closes main_to_core[i][1]
            close(read_pipes[i]);    // closes core_to_main[i][0]
        }

2.iV. write() is correctly called with properly formatted data (8 pts)
    The parent writes tasks to children via task_creator(), which formats
    the message as a string "task_id_n" and calls write():
 
        sprintf(buffer, "%d_%d", task_id, n);
        write(write_pipe, buffer, strlen(buffer)+1);
 
    The child writes results back result:
 
        write(write_pipe, &result, sizeof(result));

2.v. Correctly call the read function to read data from the pipe (4 pts)
    In task_handler(), the child reads the task string from the pipe:
 
        while((nr = read(read_pipe, buffer, sizeof(buffer)-1)) > 0){ ... }
 
    In the parent's main loop, results are read as unsigned int:
 
        read(read_pipes[i], &result, sizeof(result));

2.vi. The core subprocess can detect the close of pipes and quit the status of the wait (8 pts)
    task_handler() uses the return value of read() to detect EOF. When the
    parent closes its write end of main_to_core[i], read() returns 0 in the
    child, causing the while loop to exit. The child then returns
    from task_handler() and calls exit(0).
 
        while((nr = read(read_pipe, buffer, sizeof(buffer)-1)) > 0){ ... }
        // nr == 0 means pipe closed → loop exits → child exits

---

3. Signals

--- 

3.i. Choose appropriate signals to register (5 pts)
    Three real-time signals are used, one per core:
 
        int sig_core1 = SIGRTMAX;
        int sig_core2 = SIGRTMAX - 1;
        int sig_core3 = SIGRTMAX - 2;
 
3.ii. Correctly use sigaction to register signal handlers  (5 pts)
    Each signal is registered using sigaction() with a handler:
 
        struct sigaction sa1, sa2, sa3;
        sa1.sa_handler = sig_handler_core1;
        sigemptyset(&sa1.sa_mask);
        sa1.sa_flags = 0;
        sigaction(sig_core1, &sa1, NULL);
        // same for sa2/sig_core2 and sa3/sig_core3

3.iii. Signal handler should be correctly implemented. Its operation should keep atomic. (10 pts)
    Each handler does only one operation: incrementing a volatile sig_atomic_t
    counter, which is guaranteed to be atomic on any POSIX platform:
 
        void sig_handler_core1(int signum){ ++msg_num_core1; }
        void sig_handler_core2(int signum){ ++msg_num_core2; }
        void sig_handler_core3(int signum){ ++msg_num_core3; }
 
    No memory allocation, no printf, no non-reentrant calls are made inside
    the handlers.

3.iv. Use the proper type of global variable as the indicator of new results (4 pts)
    The result counters are declared as volatile sig_atomic_t:
 
        volatile sig_atomic_t msg_num_core1 = 0;
        volatile sig_atomic_t msg_num_core2 = 0;
        volatile sig_atomic_t msg_num_core3 = 0;

3.v. Signal should be properly sent out before a message is sent out (5 pts)
    In task_handler(), the child sends the signal to the parent via kill()
    before writing the result to the pipe:

        kill(getppid(), signum);                      // signal sent first
        write(write_pipe, &result, sizeof(result));   // result sent second

    This ensures the parent is notified that a result is incoming before
    the data arrives in the pipe, satisfying the required ordering.

--- 

4. Others 

---

4.i. Implement the command line arguments to allow user to control the number of total tasks and extracting bits (5 pts)
    The program requires exactly two arguments: total_tasks and max_bits.
    Both are validated at the start of main():
 
        if (argc != 3){ printf("Invalid input\n"); return 1; }
        int total_tasks = atoi(argv[1]);
        int max_bits    = atoi(argv[2]);
        if(total_tasks <= 0 || max_bits <= 0){ printf("Invalid input\n"); return 1; }

4.ii. The program prints properly formatted outputs as the requirement without missing any message at the end of the program (5 pts)
    During execution, the parent logs each received result:
 
        [LOG] Main process: Received result %u from Core X.
 
    At the end of the program, after all tasks complete and children are
    reaped, the results for each core are printed:
 
        Core 1: <result1>, <result2>, ...
        Core 2: <result1>, <result2>, ...
        Core 3: <result1>, <result2>, ...
    
    The code to print final result: 
        printf("Results:\n");
        for(int i=0; i<3; i++){
            printf("Core %d:", i+1);
            for(int j=0; j<core_results_count[i]; j++){
                printf(" %u", core_results[i][j]);
                if (j < core_results_count[i] - 1) printf(",");
            }
        printf("\n");
        }

    Results are stored per-core in core_results[3][total_tasks] and counts
    are tracked in core_results_count[3]









